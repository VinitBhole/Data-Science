#!/usr/bin/env python
# coding: utf-8

# In[11]:


import streamlit as st
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.impute import SimpleImputer


# In[ ]:





# In[13]:


# Load training data
train_data = pd.read_csv("Titanic_train.csv")


# In[16]:


# Impute Age with mean
imputer = SimpleImputer(strategy='mean')
train_data['Age'] = imputer.fit_transform(train_data[['Age']])
train_data['Fare'] = imputer.fit_transform(train_data[['Fare']])


# In[18]:


# Fill missing values in 'Embarked' with the most frequent value
imputer_embarked = SimpleImputer(strategy='most_frequent')
train_data['Embarked'] = imputer_embarked.fit_transform(train_data[['Embarked']]).ravel()


# In[28]:


# Drop columns that won't be used
columns_to_drop = ['Name', 'Ticket', 'Cabin', 'PassengerId']
train_data.drop(columns=[col for col in columns_to_drop if col in train_data.columns], axis=1, inplace=True)


# In[20]:


# Separate features and target variable
X_train = train_data.drop('Survived', axis=1)
y_train = train_data['Survived']


# In[21]:


# Define numeric and categorical features
numeric_features = ['Age', 'Fare', 'Pclass', 'SibSp', 'Parch']
categorical_features = ['Sex', 'Embarked']


# In[22]:


# Preprocessor for encoding and scaling
preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), numeric_features),
        ('cat', OneHotEncoder(drop='first'), categorical_features)
    ],
    remainder='passthrough'
)


# In[23]:


# Train logistic regression model
X_train = preprocessor.fit_transform(X_train)
model = LogisticRegression()
model.fit(X_train, y_train)


# In[24]:


# Define prediction function
def predict_survival(features):
    features = pd.DataFrame([features], columns=numeric_features + categorical_features)
    features_processed = preprocessor.transform(features)
    prediction = model.predict(features_processed)
    return prediction[0]


# In[25]:


# Streamlit App
st.title("Titanic Survival Prediction")
st.write("Enter the details of a passenger to predict their survival on the Titanic.")


# In[26]:


# Input fields for user to enter passenger data
age = st.number_input("Age", min_value=0, max_value=100, value=30)
fare = st.number_input("Fare", min_value=0.0, value=50.0)
pclass = st.selectbox("Passenger Class (1 = 1st, 2 = 2nd, 3 = 3rd)", [1, 2, 3])
sibsp = st.number_input("Number of Siblings/Spouses Aboard", min_value=0, value=0)
parch = st.number_input("Number of Parents/Children Aboard", min_value=0, value=0)
sex = st.selectbox("Sex", ["male", "female"])
embarked = st.selectbox("Port of Embarkation", ["C", "Q", "S"])


# In[27]:


# Predict button
if st.button("Predict Survival"):
    features = [age, fare, pclass, sibsp, parch, sex, embarked]
    survival = predict_survival(features)
    if survival == 1:
        st.success("This passenger would have survived.")
    else:
        st.error("This passenger would not have survived.")


# In[ ]:




