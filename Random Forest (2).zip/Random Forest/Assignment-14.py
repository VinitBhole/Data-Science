#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd


# In[4]:


df = pd.read_excel('glass.xlsx')


# In[5]:


df


# In[6]:


df.info()


# In[7]:


df.describe()


# In[9]:


print(df.isnull().sum())


# In[10]:


import matplotlib.pyplot as plt
import seaborn as sns


# In[12]:


# Histograms
df.hist(bins=30, figsize=(15, 10))
plt.show()


# In[14]:


# Box plots
plt.figure(figsize=(15, 10))
sns.boxplot(df=df)
plt.xticks(rotation=90)
plt.show()


# In[16]:


# Pair plots
sns.pairplot(df, hue='Type')
plt.show()


# In[17]:


from sklearn.preprocessing import StandardScaler

# Features and target
X = df.drop(columns='Type')
y = df['Type']


# In[18]:


# Standardize the features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)


# In[19]:


from sklearn.model_selection import train_test_split

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)


# In[21]:


from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

# Initialize and train the Random Forest classifier
rf = RandomForestClassifier(random_state=42)
rf.fit(X_train, y_train)


# In[22]:


# Predict on the test set
y_pred = rf.predict(X_test)


# In[23]:


# Evaluate the model
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred, average='weighted')
recall = recall_score(y_test, y_pred, average='weighted')
f1 = f1_score(y_test, y_pred, average='weighted')

print(f'Accuracy: {accuracy}')
print(f'Precision: {precision}')
print(f'Recall: {recall}')
print(f'F1-score: {f1}')


# In[24]:


from sklearn.ensemble import AdaBoostClassifier

# Initialize and train the AdaBoost classifier
ada = AdaBoostClassifier(random_state=42)
ada.fit(X_train, y_train)


# In[25]:


# Predict on the test set
y_pred_ada = ada.predict(X_test)


# In[26]:


# Evaluate the model
accuracy_ada = accuracy_score(y_test, y_pred_ada)
precision_ada = precision_score(y_test, y_pred_ada, average='weighted')
recall_ada = recall_score(y_test, y_pred_ada, average='weighted')
f1_ada = f1_score(y_test, y_pred_ada, average='weighted')

print(f'AdaBoost Accuracy: {accuracy_ada}')
print(f'AdaBoost Precision: {precision_ada}')
print(f'AdaBoost Recall: {recall_ada}')
print(f'AdaBoost F1-score: {f1_ada}')


# In[ ]:


"""Explain Bagging and Boosting methods. How is it different from each other.
Bagging (Bootstrap Aggregating)
 Bagging is an ensemble technique that creates multiple subsets of the training data by randomly sampling 
 with replacement. Each subset is used to train a base model (e.g., decision trees), and the final prediction is 
 obtained by averaging (for regression) or voting (for classification) the predictions of all the base models.
 
 Boosting
Boosting is an ensemble technique that sequentially trains base models, where each new model 
focuses on correcting the errors made by the previous models. The final prediction is obtained by a weighted 
combination of the predictions of all the base models.

Bagging reduces variance and works well with high-variance models by training them in parallel on different 
subsets of data and aggregating their predictions.

Boosting reduces both bias and variance by sequentially training models that correct the errors of their predecessors, 
often leading to better performance but with a higher risk of overfitting if not properly managed."""


# In[ ]:


"""Explain how to handle imbalance in the data.
Handling imbalanced data is a common challenge in machine learning, particularly in classification problems 
where one class significantly outnumbers the other(s).
1. Resampling Techniques
    Oversampling the Minority Class
        Increase the number of instances in the minority class by randomly duplicating instances or generating 
        new ones (e.g., using techniques like SMOTE - Synthetic Minority Over-sampling Technique).
    . Undersampling the Majority Class
        Reduce the number of instances in the majority class by randomly removing instances.
    
2. Algorithmic Techniques
    Use Algorithms Designed for Imbalanced Data
        Some algorithms are inherently better at handling imbalanced datasets, such as decision trees, 
        random forests, and ensemble methods like XGBoost and LightGBM.
        
    Adjust Class Weights
        Modify the algorithm to give more importance (weight) to the minority class.
        
3. Evaluation Metrics
     Use Appropriate Metrics
         Accuracy is not a good metric for imbalanced datasets. Instead, use metrics like Precision, Recall, F1-Score, 
         ROC-AUC, and Precision-Recall AUC.
         
4. Data Augmentation
     Synthetic Data Generation
         Generate synthetic data points for the minority class using techniques like SMOTE or ADASYN."""


# In[ ]:




